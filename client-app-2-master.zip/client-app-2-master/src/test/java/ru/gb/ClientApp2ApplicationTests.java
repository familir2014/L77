package ru.gb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientApp2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
